public class Main {
    public static void main(String[] args) {
        char[][] alphabet = new char[6][5];
        String bykva = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
        int start = 0;

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                alphabet[i][j] = bykva.charAt(start);
                start++;
                System.out.println(alphabet[i][j]+ "");
            }
        }
        System.out.println();
    }
}
//
//№2. Двумерные массивы
//Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
// Буква Ё должна быть на своём месте.